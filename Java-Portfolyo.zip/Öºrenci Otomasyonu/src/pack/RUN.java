package pack;

public class RUN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//LoginGUI sınıfı nesne haline getirilerek GUI ekranının çalışması sağlandı.
		@SuppressWarnings("unused")
		LoginGUI LGUI = new LoginGUI();
	}

}
