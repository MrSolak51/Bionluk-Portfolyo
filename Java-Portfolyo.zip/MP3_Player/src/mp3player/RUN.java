package mp3player;

public class RUN {
	public static void main(String[]args) {
		//player sınıfı nesne haline getirilerek GUI ekranının çalışması sağlandı.
		playerGUI pg = new playerGUI();
	}
}
